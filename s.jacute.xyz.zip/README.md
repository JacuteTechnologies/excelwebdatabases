**TODO**
1. Rename James's old class-names to be more accurate
2. MORE COOL ***CSS*** FEATURES YES
3. Add in the other colors in the color palette (currently black and purple)
4. Fix issue w/ captcha stopping part of the sign up process from working locally (if possible)
5. Future: Perhaps do the other websites as well? I'll need to do the project stuff, but I can make a repo for now
6. Add documentation
7. Add download links in the documentation for the php lib part
